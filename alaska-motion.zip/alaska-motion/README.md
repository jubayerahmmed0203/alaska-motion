# Alaska Purchase — Motion Graphics (Remotion)

Composition ID: `Main` · 1920×1080 · 30fps · স্কিম: Arctic Night

```bash
npm install
npx remotion studio src/index.ts
npx remotion render src/index.ts Main out/video.mp4
```

- ভয়েসওভার: `public/voiceover.mp3` রাখলে Studio প্রিভিউতে বাজবে। রেন্ডারেও মেশাতে `src/config.ts`-এ `inRender: true` করুন।
- সব টাইমিং `src/script.srt.ts` (SRT) থেকে `src/timeline.ts`-এ হিসাব হয়। SRT বদলালে সময় নিজে মিলে যাবে।
- রং/ইজিং/spring/ফন্ট: `src/theme.ts`। SFX: `public/sfx/` (`npm run sfx` দিয়ে আবার তৈরি ও যাচাই)।
