// প্রতিটি SFX-এর দৈর্ঘ্য, peak, RMS ও clipping যাচাই
import {readdirSync, readFileSync} from "node:fs";
import {dirname, join} from "node:path";
import {fileURLToPath} from "node:url";

const DIR = join(dirname(fileURLToPath(import.meta.url)), "..", "public", "sfx");
let bad = 0;
for (const f of readdirSync(DIR).filter((x) => x.endsWith(".wav")).sort()) {
  const b = readFileSync(join(DIR, f));
  const sr = b.readUInt32LE(24);
  const n = (b.length - 44) / 2;
  let peak = 0, sum = 0, clip = 0;
  for (let i = 0; i < n; i++) {
    const s = b.readInt16LE(44 + i * 2) / 32768;
    peak = Math.max(peak, Math.abs(s));
    sum += s * s;
    if (Math.abs(s) >= 0.999) clip++;
  }
  const dur = n / sr;
  const rms = Math.sqrt(sum / n);
  const max = f.startsWith("whoosh") || f.startsWith("swipe") ? 0.8 : 0.5;
  const ok = dur <= max + 0.12 && clip === 0 && peak < 0.95;
  if (!ok) bad++;
  console.log(`${ok ? "OK " : "BAD"} ${f.padEnd(12)} ${dur.toFixed(2)}s  peak=${peak.toFixed(2)}  rms=${rms.toFixed(3)}  clip=${clip}`);
}
process.exit(bad ? 1 : 0);
