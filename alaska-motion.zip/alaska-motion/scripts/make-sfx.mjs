// কোডে সিন্থেসাইজ করা SFX কিট (কোনো ডাউনলোড নেই, সম্পূর্ণ ডিটারমিনিস্টিক)
// pop = pitch-drop sine, click = high-pass noise burst, whoosh/swipe = band-pass noise sweep,
// chime = নরম ওভারটোনসহ ছোট decay, thud = নরম লো-ফ্রিকোয়েন্সি থাড। সব সাউন্ডে লো-পাস + খুব ছোট reverb।
import {mkdirSync, writeFileSync} from "node:fs";
import {dirname, join} from "node:path";
import {fileURLToPath} from "node:url";

const SR = 44100;
const OUT = join(dirname(fileURLToPath(import.meta.url)), "..", "public", "sfx");
mkdirSync(OUT, {recursive: true});

let seed = 1234567;
const rnd = () => ((seed = (seed * 1664525 + 1013904223) >>> 0) / 4294967296) * 2 - 1;

const biquad = (type, fc, q) => {
  const w = (2 * Math.PI * fc) / SR;
  const al = Math.sin(w) / (2 * q);
  const c = Math.cos(w);
  let b0, b1, b2, a0, a1, a2;
  if (type === "lp") { b0 = (1 - c) / 2; b1 = 1 - c; b2 = (1 - c) / 2; }
  else if (type === "hp") { b0 = (1 + c) / 2; b1 = -(1 + c); b2 = (1 + c) / 2; }
  else { b0 = al; b1 = 0; b2 = -al; } // bp
  a0 = 1 + al; a1 = -2 * c; a2 = 1 - al;
  return {b0: b0 / a0, b1: b1 / a0, b2: b2 / a0, a1: a1 / a0, a2: a2 / a0, x1: 0, x2: 0, y1: 0, y2: 0};
};
const run = (f, x) => {
  const y = f.b0 * x + f.b1 * f.x1 + f.b2 * f.x2 - f.a1 * f.y1 - f.a2 * f.y2;
  f.x2 = f.x1; f.x1 = x; f.y2 = f.y1; f.y1 = y;
  return y;
};

const finish = (buf, lpHz = 9000) => {
  const n = buf.length;
  const lp = biquad("lp", lpHz, 0.7);
  const dry = buf.map((x) => run(lp, x));
  // খুব ছোট reverb: দুটি হালকা ট্যাপ
  const out = new Float32Array(n + Math.floor(SR * 0.09));
  for (let i = 0; i < dry.length; i++) {
    out[i] += dry[i];
    out[i + Math.floor(SR * 0.031)] += dry[i] * 0.16;
    out[i + Math.floor(SR * 0.053)] += dry[i] * 0.09;
  }
  const fade = Math.floor(SR * 0.02);
  for (let i = 0; i < fade; i++) out[out.length - 1 - i] *= i / fade;
  return out;
};

const gen = (secs, fn) => {
  const n = Math.floor(SR * secs);
  const b = new Float32Array(n);
  for (let i = 0; i < n; i++) b[i] = fn(i / SR, i);
  return b;
};
const att = (t, a) => Math.min(1, t / a);

const sounds = {
  pop() {
    let ph = 0;
    return finish(gen(0.2, (t) => {
      const f = 190 + 520 * Math.exp(-t * 30);
      ph += (2 * Math.PI * f) / SR;
      return (Math.sin(ph) + 0.12 * Math.sin(2 * ph)) * att(t, 0.004) * Math.exp(-t * 20);
    }), 6500);
  },
  click() {
    const hp = biquad("hp", 2600, 0.8);
    const bp = biquad("bp", 4200, 1.2);
    return finish(gen(0.12, (t) => {
      const n = rnd();
      const burst = (run(hp, n) * 0.6 + run(bp, n) * 0.8) * Math.exp(-t * 85);
      const tick = Math.sin(2 * Math.PI * 1900 * t) * Math.exp(-t * 110) * 0.35;
      return (burst + tick) * att(t, 0.0012);
    }), 8000);
  },
  whoosh() {
    const bp = biquad("bp", 600, 1.1);
    let fc = 0;
    return finish(gen(0.55, (t, i) => {
      if (i % 64 === 0) { const f = 450 * Math.pow(3600 / 450, t / 0.55); Object.assign(bp, biquad("bp", f, 1.1), {x1: bp.x1, x2: bp.x2, y1: bp.y1, y2: bp.y2}); }
      const env = Math.pow(Math.sin(Math.PI * Math.min(1, t / 0.55)), 2.2);
      return run(bp, rnd()) * env * 1.6;
    }), 7500);
  },
  swipe() {
    const bp = biquad("bp", 3000, 1.0);
    return finish(gen(0.6, (t, i) => {
      if (i % 64 === 0) { const f = 3200 * Math.pow(520 / 3200, t / 0.6); Object.assign(bp, biquad("bp", f, 1.0), {x1: bp.x1, x2: bp.x2, y1: bp.y1, y2: bp.y2}); }
      const x = Math.min(1, t / 0.6);
      const env = Math.pow(Math.sin(Math.PI * Math.pow(x, 0.7)), 2);
      return run(bp, rnd()) * env * 1.6;
    }), 7000);
  },
  chime() {
    const partials = [[880, 1, 7], [1318, 0.45, 10], [1760, 0.28, 14], [2640, 0.1, 22]];
    return finish(gen(0.4, (t) => {
      let s = 0;
      for (const [f, a, d] of partials) s += Math.sin(2 * Math.PI * f * t) * a * Math.exp(-t * d);
      return s * att(t, 0.005);
    }), 7000);
  },
  thud() {
    let ph = 0;
    return finish(gen(0.36, (t) => {
      const f = 46 + 40 * Math.exp(-t * 28);
      ph += (2 * Math.PI * f) / SR;
      return Math.sin(ph) * att(t, 0.006) * Math.exp(-t * 11) + rnd() * 0.05 * Math.exp(-t * 90);
    }), 600);
  },
};

const TARGET_RMS = 0.11; // সব সাউন্ড একই লাউডনেস স্তরে
const PEAK_MAX = 0.8; // clipping এড়াতে

const wav = (samples) => {
  const data = Buffer.alloc(samples.length * 2);
  samples.forEach((s, i) => data.writeInt16LE(Math.max(-32768, Math.min(32767, Math.round(s * 32767))), i * 2));
  const h = Buffer.alloc(44);
  h.write("RIFF", 0); h.writeUInt32LE(36 + data.length, 4); h.write("WAVE", 8); h.write("fmt ", 12);
  h.writeUInt32LE(16, 16); h.writeUInt16LE(1, 20); h.writeUInt16LE(1, 22); h.writeUInt32LE(SR, 24);
  h.writeUInt32LE(SR * 2, 28); h.writeUInt16LE(2, 32); h.writeUInt16LE(16, 34); h.write("data", 36); h.writeUInt32LE(data.length, 40);
  return Buffer.concat([h, data]);
};

for (const [name, make] of Object.entries(sounds)) {
  seed = 1234567;
  const raw = make();
  let peak = 0, sum = 0;
  for (const s of raw) { peak = Math.max(peak, Math.abs(s)); sum += s * s; }
  const rms = Math.sqrt(sum / raw.length);
  const g = Math.min(TARGET_RMS / rms, PEAK_MAX / peak);
  writeFileSync(join(OUT, `${name}.wav`), wav(raw.map((s) => s * g)));
}
console.log("SFX তৈরি:", Object.keys(sounds).join(", "));
