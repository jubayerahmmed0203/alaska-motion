import React from "react";
import {AbsoluteFill, Sequence} from "remotion";
import {fontFamily} from "./theme";
import {scenes} from "./timeline";
import {BgMesh, Grade, Grain, Vignette} from "./components/Bg";
import {SceneShell} from "./components/SceneShell";
import {SfxTrack} from "./components/Sfx";
import {PreviewAudio} from "./components/PreviewAudio";
import {Hook} from "./scenes/Hook";
import {Deal} from "./scenes/Deal";
import {Folly} from "./scenes/Folly";
import {Boom} from "./scenes/Boom";
import {Giant} from "./scenes/Giant";
import {Owner} from "./scenes/Owner";
import {Vote} from "./scenes/Vote";

const map: Record<string, React.FC> = {hook: Hook, deal: Deal, folly: Folly, boom: Boom, giant: Giant, owner: Owner, vote: Vote};

export const Main: React.FC = () => (
  <AbsoluteFill style={{fontFamily, overflow: "hidden"}}>
    <BgMesh />
    {scenes.map((s) => {
      const C = map[s.id];
      return (
        <Sequence key={s.id} from={s.from} durationInFrames={s.dur}>
          <SceneShell from={s.from} dur={s.dur}>
            <C />
          </SceneShell>
        </Sequence>
      );
    })}
    <Grade />
    <Grain />
    <Vignette />
    <SfxTrack />
    <PreviewAudio />
  </AbsoluteFill>
);
