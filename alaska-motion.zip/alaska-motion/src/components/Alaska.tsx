import React from "react";
import {interpolate, useVideoConfig} from "remotion";
import {alpha, colors, ease} from "../theme";
import {clamp, useAbs} from "../motion";

// সরলীকৃত আলাস্কা সিলুয়েট (lon, lat) → নিজে এঁকে প্রজেক্ট করা, লোগো/অ্যাসেট নয়
const LL: Array<[number, number]> = [
  [-141.0, 69.65], [-143.5, 70.1], [-146.0, 70.2], [-149.5, 70.5], [-152.3, 70.9],
  [-154.8, 71.2], [-156.6, 71.35], [-159.5, 70.8], [-161.9, 70.3], [-163.6, 69.6],
  [-166.0, 68.95], [-166.8, 68.35], [-164.6, 67.85], [-162.6, 66.95], [-163.7, 66.55],
  [-166.2, 66.25], [-168.1, 65.65], [-166.4, 65.25], [-164.5, 64.55], [-163.0, 64.55],
  [-160.8, 63.9], [-162.0, 63.45], [-164.8, 63.0], [-166.2, 61.7], [-164.8, 60.5],
  [-162.2, 59.9], [-162.0, 59.1], [-161.9, 58.65], [-160.0, 58.9], [-158.5, 58.85],
  [-157.0, 58.7], [-157.6, 58.0], [-158.6, 56.9], [-160.6, 56.1], [-162.4, 55.45],
  [-164.7, 54.85], [-164.9, 54.62], [-163.5, 54.7], [-162.0, 55.0], [-160.3, 55.5],
  [-158.9, 56.0], [-157.3, 56.7], [-155.5, 57.6], [-154.2, 58.4], [-153.6, 59.2],
  [-153.1, 60.0], [-151.5, 60.8], [-150.2, 61.25], [-149.3, 60.95], [-150.9, 60.55],
  [-151.6, 59.7], [-151.8, 59.2], [-150.0, 59.5], [-149.4, 60.1], [-148.2, 60.6],
  [-146.3, 61.1], [-145.7, 60.5], [-144.0, 60.0], [-142.0, 59.95], [-140.0, 59.6],
  [-137.6, 58.55], [-136.6, 58.2], [-135.6, 57.1], [-134.4, 56.1], [-133.4, 55.0],
  [-131.6, 54.75], [-130.0, 54.7], [-130.3, 56.1], [-132.0, 56.8], [-133.5, 58.2],
  [-135.5, 59.8], [-137.4, 59.0], [-139.0, 60.3], [-141.0, 60.3],
];
const ISLES: Array<[number, number, number]> = [
  [-153.4, 57.5, 11], [-166.5, 53.85, 5], [-169.0, 53.3, 5], [-171.5, 52.85, 5],
  [-174.0, 52.2, 4.5], [-176.6, 51.9, 4], [-179.2, 51.5, 3.5],
];
const px = (lon: number) => (lon + 185) * 0.47 * 22;
const py = (lat: number) => (72 - lat) * 22;
const D = LL.map(([lo, la], i) => `${i === 0 ? "M" : "L"}${px(lo).toFixed(1)} ${py(la).toFixed(1)}`).join(" ") + " Z";

export const ALASKA_VIEW = {w: 590, h: 470};

/** পথ আঁকা → ফিল ফেড → দ্বীপ ফুটে ওঠা */
export const Alaska: React.FC<{
  width: number;
  start: number;
  draw?: number;
  fill?: string;
  stroke?: string;
  strokeW?: number;
  glow?: boolean;
}> = ({width, start, draw = 36, fill, stroke = colors.hero, strokeW = 3.5, glow = true}) => {
  const f = useAbs();
  const {fps} = useVideoConfig();
  const d = interpolate(f, [start, start + draw], [0, 1], {easing: ease.inOut, ...clamp});
  const fi = interpolate(f, [start + draw * 0.6, start + draw + 14], [0, 1], {easing: ease.out, ...clamp});
  const pulse = 0.5 + 0.5 * Math.sin((f / fps) * 2.2);
  return (
    <svg
      width={width}
      height={(width * ALASKA_VIEW.h) / ALASKA_VIEW.w}
      viewBox={`0 0 ${ALASKA_VIEW.w} ${ALASKA_VIEW.h}`}
      style={{overflow: "visible", filter: glow ? `drop-shadow(0 0 ${14 + pulse * 10}px ${alpha(stroke, 0.45)})` : undefined}}
    >
      <defs>
        <linearGradient id="akfill" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor={colors.surfaceHi} />
          <stop offset="1" stopColor={colors.surface} />
        </linearGradient>
      </defs>
      <path d={D} fill={fill ?? "url(#akfill)"} fillOpacity={fi} />
      <path
        d={D}
        pathLength={1}
        fill="none"
        stroke={stroke}
        strokeWidth={strokeW}
        strokeLinejoin="round"
        strokeLinecap="round"
        strokeDasharray={1}
        strokeDashoffset={1 - d}
      />
      {ISLES.map(([lo, la, r], i) => (
        <circle
          key={i}
          cx={px(lo)}
          cy={py(la)}
          r={r * fi}
          fill={fill ?? colors.surfaceHi}
          stroke={stroke}
          strokeWidth={2.5}
          opacity={fi}
        />
      ))}
    </svg>
  );
};
