import React from "react";
import {AbsoluteFill, random, useCurrentFrame, useVideoConfig} from "remotion";
import {alpha, colors} from "../theme";

/** লেয়ার ১: ব্যাকগ্রাউন্ড মেশ + ডট গ্রিড + বরফের কণা */
export const BgMesh: React.FC = () => {
  const f = useCurrentFrame();
  const {fps, width, height} = useVideoConfig();
  const t = f / fps;
  const blob = (x: number, y: number, sp: number, ph: number) => ({
    x: x + Math.sin(t * sp + ph) * 8,
    y: y + Math.cos(t * sp * 0.8 + ph) * 8,
  });
  const a = blob(18, 22, 0.35, 0);
  const b = blob(86, 82, 0.28, 2);
  const c = blob(70, 8, 0.22, 4);
  const bg = [
    `radial-gradient(circle at ${a.x}% ${a.y}%, ${alpha(colors.hero, 0.2)} 0%, transparent 52%)`,
    `radial-gradient(circle at ${b.x}% ${b.y}%, ${alpha(colors.surfaceHi, 0.95)} 0%, transparent 60%)`,
    `radial-gradient(circle at ${c.x}% ${c.y}%, ${alpha(colors.accent, 0.07)} 0%, transparent 40%)`,
    `linear-gradient(180deg, ${colors.bg} 0%, ${colors.bgDeep} 100%)`,
  ].join(", ");

  return (
    <AbsoluteFill style={{background: bg}}>
      <AbsoluteFill
        style={{
          backgroundImage: `radial-gradient(${alpha(colors.text, 0.07)} 1.6px, transparent 1.7px)`,
          backgroundSize: "52px 52px",
          backgroundPosition: `${(t * 6) % 52}px ${(t * 3) % 52}px`,
        }}
      />
      {new Array(34).fill(0).map((_, i) => {
        const sx = random(`sx${i}`);
        const sy = random(`sy${i}`);
        const sz = 3 + random(`sz${i}`) * 5;
        const sp = 14 + random(`sp${i}`) * 26;
        const y = (sy * (height + 80) + t * sp) % (height + 80) - 40;
        const x = sx * width + Math.sin(t * 0.6 + i) * 24;
        return (
          <div
            key={i}
            style={{
              position: "absolute",
              left: x,
              top: y,
              width: sz,
              height: sz,
              borderRadius: sz,
              background: alpha(colors.text, 0.12 + random(`so${i}`) * 0.22),
            }}
          />
        );
      })}
    </AbsoluteFill>
  );
};

/** লেয়ার ৪: কালার গ্রেড */
export const Grade: React.FC = () => (
  <AbsoluteFill
    style={{
      background: `linear-gradient(160deg, ${alpha(colors.hero, 0.05)} 0%, transparent 40%, ${alpha(colors.bgDeep, 0.3)} 100%)`,
      pointerEvents: "none",
    }}
  />
);

/** লেয়ার ৫ক: গ্রেন */
export const Grain: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <AbsoluteFill style={{opacity: 0.07, mixBlendMode: "overlay", pointerEvents: "none"}}>
      <svg width="100%" height="100%">
        <filter id="grain">
          <feTurbulence
            type="fractalNoise"
            baseFrequency="0.8"
            numOctaves={2}
            seed={Math.floor(f / 2)}
            stitchTiles="stitch"
          />
          <feColorMatrix type="saturate" values="0" />
        </filter>
        <rect width="100%" height="100%" filter="url(#grain)" />
      </svg>
    </AbsoluteFill>
  );
};

/** লেয়ার ৫খ: ভিনিয়েট */
export const Vignette: React.FC = () => (
  <AbsoluteFill
    style={{
      background: `radial-gradient(ellipse at center, transparent 55%, ${alpha(colors.bgDeep, 0.7)} 100%)`,
      pointerEvents: "none",
    }}
  />
);
