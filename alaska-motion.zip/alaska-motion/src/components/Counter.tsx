import React from "react";
import {interpolate} from "remotion";
import {colors, ease} from "../theme";
import {bn, clamp, useAbs} from "../motion";

/** কাউন্টার রোল: শুধু স্ক্রিপ্টে থাকা সংখ্যার জন্য। বাংলা অঙ্কে দেখায়। */
export const Counter: React.FC<{
  to: number;
  start: number;
  dur: number;
  size: number;
  decimals?: number;
  from?: number;
  color?: string;
  weight?: number;
}> = ({to, start, dur, size, decimals = 0, from = 0, color, weight = 700}) => {
  const f = useAbs();
  const v = interpolate(f, [start, start + dur], [from, to], {easing: ease.out, ...clamp});
  return (
    <span
      style={{
        fontSize: size,
        fontWeight: weight,
        color: color ?? colors.accent,
        lineHeight: 1.3,
        letterSpacing: 0,
        display: "inline-block",
        fontVariantNumeric: "tabular-nums",
      }}
    >
      {bn(v.toFixed(decimals))}
    </span>
  );
};
