import React from "react";
import {alpha, colors, radius, shadow} from "../theme";

export const Glass: React.FC<{
  w?: number;
  h?: number;
  r?: number;
  style?: React.CSSProperties;
  border?: string;
  children?: React.ReactNode;
}> = ({w, h, r = radius.lg, style, border, children}) => (
  <div
    style={{
      position: "relative",
      boxSizing: "border-box",
      width: w,
      height: h,
      borderRadius: r,
      overflow: "hidden",
      background: `linear-gradient(145deg, ${alpha(colors.surfaceHi, 0.88)}, ${alpha(colors.surface, 0.82)})`,
      border: `1.5px solid ${border ?? alpha(colors.text, 0.14)}`,
      boxShadow: shadow.card,
      ...style,
    }}
  >
    <div
      style={{
        position: "absolute",
        inset: 0,
        background: `linear-gradient(180deg, ${alpha(colors.text, 0.08)} 0%, transparent 38%)`,
        pointerEvents: "none",
      }}
    />
    {children}
  </div>
);

export const Pill: React.FC<{
  text: string;
  color?: string;
  size?: number;
  style?: React.CSSProperties;
}> = ({text, color = colors.accent, size = 34, style}) => (
  <div
    style={{
      boxSizing: "border-box",
      display: "inline-flex",
      alignItems: "center",
      padding: `${Math.round(size * 0.22)}px ${Math.round(size * 0.7)}px`,
      borderRadius: 999,
      fontSize: size,
      fontWeight: 600,
      lineHeight: 1.4,
      letterSpacing: 0,
      color,
      background: alpha(color, 0.14),
      border: `1.5px solid ${alpha(color, 0.45)}`,
      ...style,
    }}
  >
    {text}
  </div>
);
