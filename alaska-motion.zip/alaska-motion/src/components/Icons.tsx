import React from "react";
import {alpha, colors} from "../theme";

type I = {size?: number; color?: string; sw?: number};

export const Check: React.FC<I> = ({size = 60, color = colors.bg, sw = 9}) => (
  <svg width={size} height={size} viewBox="0 0 64 64" fill="none">
    <path d="M14 34 L27 46 L51 18" stroke={color} strokeWidth={sw} strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

export const Cross: React.FC<I> = ({size = 60, color = colors.bg, sw = 9}) => (
  <svg width={size} height={size} viewBox="0 0 64 64" fill="none">
    <path d="M18 18 L46 46 M46 18 L18 46" stroke={color} strokeWidth={sw} strokeLinecap="round" />
  </svg>
);

export const Mountain: React.FC<I> = ({size = 70, color = colors.hero}) => (
  <svg width={size} height={size} viewBox="0 0 80 80" fill="none">
    <path d="M6 66 L30 22 L44 44 L54 30 L74 66 Z" fill={alpha(color, 0.2)} stroke={color} strokeWidth={4} strokeLinejoin="round" />
    <path d="M24 33 L30 22 L36 33" stroke={colors.text} strokeWidth={4} strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

export const Expand: React.FC<I> = ({size = 70, color = colors.hero}) => (
  <svg width={size} height={size} viewBox="0 0 80 80" fill="none" stroke={color} strokeWidth={5} strokeLinecap="round" strokeLinejoin="round">
    <path d="M14 30 V14 H30 M50 14 H66 V30 M66 50 V66 H50 M30 66 H14 V50" />
    <rect x="30" y="30" width="20" height="20" rx="4" fill={alpha(color, 0.25)} />
  </svg>
);

export const Layers: React.FC<I> = ({size = 70, color = colors.hero}) => (
  <svg width={size} height={size} viewBox="0 0 80 80" fill="none" stroke={color} strokeWidth={5} strokeLinejoin="round" strokeLinecap="round">
    <path d="M40 12 L70 28 L40 44 L10 28 Z" fill={alpha(color, 0.25)} />
    <path d="M10 42 L40 58 L70 42" />
    <path d="M10 56 L40 72 L70 56" />
  </svg>
);

export const GoldBars: React.FC<{width?: number}> = ({width = 300}) => {
  const bar = (x: number, y: number, w: number, h: number, k: string) => (
    <g key={k}>
      <path d={`M${x + 14} ${y} H${x + w - 14} L${x + w} ${y + h} H${x} Z`} fill={`url(#gb)`} />
      <path d={`M${x + 14} ${y} H${x + w - 14} L${x + w - 20} ${y + 12} H${x + 20} Z`} fill={colors.accentLight} opacity={0.85} />
    </g>
  );
  return (
    <svg width={width} height={(width * 150) / 220} viewBox="0 0 220 150">
      <defs>
        <linearGradient id="gb" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor={colors.accent} />
          <stop offset="1" stopColor={colors.accentDark} />
        </linearGradient>
      </defs>
      {bar(8, 92, 100, 50, "a")}
      {bar(112, 92, 100, 50, "b")}
      {bar(60, 38, 100, 50, "c")}
    </svg>
  );
};

export const OilDrop: React.FC<{width?: number}> = ({width = 200}) => (
  <svg width={width} height={(width * 240) / 200} viewBox="0 0 200 240">
    <defs>
      <linearGradient id="od" x1="0" y1="0" x2="1" y2="1">
        <stop offset="0" stopColor={colors.surfaceHi} />
        <stop offset="1" stopColor={colors.bgDeep} />
      </linearGradient>
    </defs>
    <path
      d="M100 12 C100 12 34 100 34 150 a66 66 0 0 0 132 0 C166 100 100 12 100 12 Z"
      fill="url(#od)"
      stroke={colors.hero}
      strokeWidth={7}
      strokeLinejoin="round"
    />
    <path d="M62 150 a38 38 0 0 0 28 36" stroke={colors.text} strokeOpacity={0.55} strokeWidth={9} strokeLinecap="round" fill="none" />
  </svg>
);

export const StarPoly: React.FC<{size?: number; color?: string}> = ({size = 70, color = colors.bg}) => {
  const pts = new Array(10).fill(0).map((_, i) => {
    const r = i % 2 === 0 ? 46 : 19;
    const a = (Math.PI / 5) * i - Math.PI / 2;
    return `${50 + r * Math.cos(a)},${50 + r * Math.sin(a)}`;
  });
  return (
    <svg width={size} height={size} viewBox="0 0 100 100">
      <polygon points={pts.join(" ")} fill={color} />
    </svg>
  );
};
