import React, {useEffect, useState} from "react";
import {Audio, continueRender, delayRender, getRemotionEnvironment, staticFile} from "remotion";
import {VOICEOVER} from "../config";

/** public/voiceover.mp3 থাকলে বাজবে, না থাকলে নীরবে বাদ। রেন্ডারে ডিফল্টে বন্ধ। */
export const PreviewAudio: React.FC = () => {
  const [ok, setOk] = useState(false);
  const rendering = getRemotionEnvironment().isRendering;
  const enabled = rendering ? VOICEOVER.inRender : VOICEOVER.inPreview;
  const [handle] = useState(() => (enabled ? delayRender("check voiceover") : null));

  useEffect(() => {
    if (!enabled || handle === null) return;
    fetch(staticFile(VOICEOVER.file), {method: "HEAD"})
      .then((r) => setOk(r.ok && (r.headers.get("content-type") ?? "").includes("audio")))
      .catch(() => setOk(false))
      .finally(() => continueRender(handle));
  }, [enabled, handle]);

  if (!enabled || !ok) return null;
  return <Audio src={staticFile(VOICEOVER.file)} volume={VOICEOVER.volume} />;
};
