import React from "react";
import {interpolate, useCurrentFrame} from "remotion";
import {EXIT_FRAMES, ease} from "../theme";
import {SceneStart, clamp} from "../motion";

/** সিনের মোড়ক: absolute ফ্রেম context + মসৃণ এক্সিট (swipe + blur) */
export const SceneShell: React.FC<{from: number; dur: number; children: React.ReactNode}> = ({from, dur, children}) => {
  const f = useCurrentFrame();
  const out = interpolate(f, [dur - EXIT_FRAMES, dur], [0, 1], {easing: ease.in, ...clamp});
  return (
    <SceneStart.Provider value={from}>
      <div
        style={{
          position: "absolute",
          inset: 0,
          opacity: 1 - out,
          transform: `translateX(${-out * 90}px) scale(${1 + out * 0.03})`,
          filter: out > 0 ? `blur(${out * 12}px)` : undefined,
        }}
      >
        {children}
      </div>
    </SceneStart.Provider>
  );
};
