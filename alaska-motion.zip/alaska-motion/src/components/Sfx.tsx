import React from "react";
import {Audio, Sequence, staticFile} from "remotion";
import {sfxEvents} from "../sfx";

/** SFX ট্র্যাক: ইভেন্টের ফ্রেম SRT-ভিত্তিক timeline থেকে আসে */
export const SfxTrack: React.FC = () => (
  <>
    {sfxEvents.map((e, i) => (
      <Sequence key={i} from={e.f} durationInFrames={45} layout="none">
        <Audio src={staticFile(`sfx/${e.name}.wav`)} volume={e.vol} />
      </Sequence>
    ))}
  </>
);
