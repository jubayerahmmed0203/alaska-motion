import React from "react";
import {interpolate, useVideoConfig} from "remotion";
import {alpha, colors, ease} from "../theme";
import {clamp, enter, useAbs} from "../motion";

type Props = {
  text: string;
  start: number;
  size: number;
  weight?: number;
  color?: string;
  stagger?: number;
  /** প্রতিটি শব্দের আলাদা শুরু-ফ্রেম (SRT anchor) */
  wordStarts?: number[];
  wordColors?: Array<string | undefined>;
  /** হাইলাইট সুইপ হবে এমন শব্দের ইনডেক্স */
  sweep?: number[];
  sweepColor?: string;
  align?: "center" | "left";
  maxWidth?: number;
};

/** শব্দ ধরে স্ট্যাগার্ড রিভিল। বাংলা কখনো অক্ষর ধরে ভাঙে না: বিভাজন শুধু স্পেসে। */
export const WordReveal: React.FC<Props> = (p) => {
  const f = useAbs();
  const {fps} = useVideoConfig();
  const words = p.text.split(" ");
  return (
    <div
      style={{
        display: "flex",
        flexWrap: "wrap",
        justifyContent: p.align === "left" ? "flex-start" : "center",
        columnGap: Math.round(p.size * 0.28),
        rowGap: Math.round(p.size * 0.02),
        maxWidth: p.maxWidth,
        fontSize: p.size,
        fontWeight: p.weight ?? 700,
        lineHeight: 1.4,
        letterSpacing: 0,
        color: p.color ?? colors.text,
      }}
    >
      {words.map((w, i) => {
        const st = p.wordStarts ? p.wordStarts[i] : p.start + i * (p.stagger ?? 4);
        const e = enter(f, st, fps, {dist: p.size * 0.4, scale: 0.92, blur: 10});
        const sw = p.sweep?.includes(i);
        const sweepP = interpolate(f, [st + 8, st + 22], [0, 1], {easing: ease.out, ...clamp});
        return (
          <span
            key={i}
            style={{
              position: "relative",
              display: "inline-block",
              color: p.wordColors?.[i],
              ...e.style,
            }}
          >
            {sw ? (
              <span
                style={{
                  position: "absolute",
                  left: -Math.round(p.size * 0.1),
                  right: -Math.round(p.size * 0.1),
                  top: "14%",
                  height: "72%",
                  borderRadius: 10,
                  background: alpha(p.sweepColor ?? colors.accent, 0.2),
                  transformOrigin: "left center",
                  transform: `scaleX(${sweepP})`,
                  zIndex: -1,
                }}
              />
            ) : null}
            {w}
          </span>
        );
      })}
    </div>
  );
};
