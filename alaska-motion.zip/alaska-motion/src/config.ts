// ভয়েসওভার ফ্ল্যাগ: public/voiceover.mp3 থাকলে Studio প্রিভিউতে বাজবে, না থাকলে নীরবে বাদ।
export const VOICEOVER = {
  file: "voiceover.mp3",
  inPreview: true,
  // ডিফল্টে রেন্ডারে বন্ধ। রেন্ডারেও ভয়েসওভার মিশাতে চাইলে true করুন।
  inRender: false,
  volume: 1,
};
