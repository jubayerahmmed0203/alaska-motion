import {createContext, useContext} from "react";
import {interpolate, spring, useCurrentFrame} from "remotion";
import {ease, springs} from "./theme";

type Cfg = {damping: number; stiffness: number; mass?: number};

export const SceneStart = createContext(0);
/** Sequence-এর ভেতরেও পুরো ভিডিওর absolute ফ্রেম পাওয়া যায় */
export const useAbs = () => useCurrentFrame() + useContext(SceneStart);

export const clamp = {
  extrapolateLeft: "clamp",
  extrapolateRight: "clamp",
} as const;

export const prog = (f: number, start: number, fps: number, cfg: Cfg = springs.pop) =>
  spring({frame: Math.max(0, f - start), fps, config: cfg});

/** এন্ট্রি: opacity + translate + scale (+blur) একসাথে */
export const enter = (
  f: number,
  start: number,
  fps: number,
  o: {dist?: number; x?: number; scale?: number; cfg?: Cfg; blur?: number} = {},
) => {
  const p = prog(f, start, fps, o.cfg ?? springs.pop);
  const op = interpolate(p, [0, 0.5], [0, 1], clamp);
  const s0 = o.scale ?? 0.9;
  const style: React.CSSProperties = {
    opacity: f < start ? 0 : op,
    transform: `translate(${(1 - p) * (o.x ?? 0)}px, ${(1 - p) * (o.dist ?? 40)}px) scale(${s0 + (1 - s0) * p})`,
    filter: o.blur ? `blur(${(1 - op) * o.blur}px)` : undefined,
  };
  return {p, style};
};

/** এক্সিট দ্রুত (≈১০ ফ্রেম), এন্ট্রির চেয়ে ছোট */
export const exitP = (f: number, at: number, dur = 10) =>
  interpolate(f, [at, at + dur], [0, 1], {easing: ease.in, ...clamp});

export const exitStyle = (p: number, dy = -36): React.CSSProperties => ({
  opacity: 1 - p,
  transform: `translateY(${p * dy}px) scale(${1 - p * 0.04})`,
  filter: p > 0 ? `blur(${p * 10}px)` : undefined,
});

/** idle micro-motion */
export const breathe = (f: number, fps: number, amp = 6, phase = 0, period = 1.6) =>
  Math.sin((f / (fps * period)) * Math.PI * 2 + phase) * amp;

const D = "০১২৩৪৫৬৭৮৯";
export const bn = (s: string) => s.replace(/[0-9]/g, (d) => D[Number(d)]);
