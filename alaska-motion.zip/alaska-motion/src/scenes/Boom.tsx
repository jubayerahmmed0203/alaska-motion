import React from "react";
import {interpolate, useVideoConfig} from "remotion";
import {alpha, colors, ease, shadow} from "../theme";
import {breathe, clamp, enter, useAbs} from "../motion";
import {Glass, Pill} from "../components/Glass";
import {GoldBars, OilDrop} from "../components/Icons";
import {T} from "../timeline";

const Card: React.FC<{left: number; start: number; pill: string; title: string; hero?: boolean; seed: number; children: React.ReactNode}> = ({left, start, pill, title, hero, seed, children}) => {
  const f = useAbs();
  const {fps} = useVideoConfig();
  const e = enter(f, start, fps, {dist: 90, scale: 0.88});
  const c = hero ? colors.hero : colors.accent;
  return (
    <div style={{position: "absolute", left, top: 110 + breathe(f, fps, 6, seed), width: 780, height: 560, ...e.style}}>
      <Glass w={780} h={560} border={alpha(c, 0.4)}>
        <div style={{position: "absolute", top: 36, left: 44}}>
          <Pill text={pill} color={c} size={34} />
        </div>
        <div style={{position: "absolute", top: 120, left: 0, right: 0, height: 260, display: "flex", alignItems: "center", justifyContent: "center"}}>{children}</div>
        <div style={{position: "absolute", bottom: 34, left: 0, right: 0, textAlign: "center", fontSize: 88, fontWeight: 700, lineHeight: 1.4, color: colors.text, letterSpacing: 0}}>
          {title}
        </div>
      </Glass>
    </div>
  );
};

const Chart: React.FC = () => {
  const f = useAbs();
  const {fps} = useVideoConfig();
  const x0 = 150;
  const x1 = 1770;
  const y0 = 990;
  const y1 = 760;
  const d = interpolate(f, [T.boom.gold, T.boom.value + 34], [0, 1], {easing: ease.inOut, ...clamp});
  const path = `M${x0} ${y0} C ${x0 + 520} ${y0}, ${x0 + 760} ${y0 - 40}, ${x0 + 1000} ${y0 - 90} S ${x1 - 220} ${y1 + 10}, ${x1} ${y1}`;
  const chip = enter(f, T.boom.value, fps, {dist: 30, scale: 0.8});
  const endGlow = interpolate(d, [0.9, 1], [0, 1], clamp);
  return (
    <>
      <svg style={{position: "absolute", left: 0, top: 0}} width={1920} height={1080}>
        <line x1={x0} y1={y0 + 14} x2={x1} y2={y0 + 14} stroke={alpha(colors.text, 0.2)} strokeWidth={3} />
        <path d={`${path} L ${x1} ${y0 + 14} L ${x0} ${y0 + 14} Z`} fill={alpha(colors.accent, 0.1 * d)} />
        <path d={path} pathLength={1} fill="none" stroke={colors.accent} strokeWidth={9} strokeLinecap="round" strokeDasharray={1} strokeDashoffset={1 - d} style={{filter: `drop-shadow(0 0 12px ${alpha(colors.accent, 0.6)})`}} />
        <circle cx={x1} cy={y1} r={16 + endGlow * 6} fill={colors.accent} opacity={endGlow} />
      </svg>
      <div style={{position: "absolute", left: x1 - 560, top: 684, ...chip.style}}>
        <Pill text="আরও মূল্য" size={52} color={colors.accent} style={{background: alpha(colors.bg, 0.85)}} />
      </div>
    </>
  );
};

export const Boom: React.FC = () => (
  <div style={{position: "absolute", inset: 0}}>
    <Card left={150} start={T.boom.gold} pill="প্রথমে" title="গোল্ড রাশ" seed={0}>
      <GoldBars width={330} />
    </Card>
    <Card left={990} start={T.boom.oil} pill="পরে" title="তেলের মজুত" hero seed={2}>
      <OilDrop width={200} />
    </Card>
    <Chart />
  </div>
);
