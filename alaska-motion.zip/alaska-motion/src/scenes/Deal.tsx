import React from "react";
import {interpolate, useVideoConfig} from "remotion";
import {alpha, colors, ease, radius, shadow} from "../theme";
import {breathe, clamp, enter, exitP, exitStyle, prog, useAbs} from "../motion";
import {WordReveal} from "../components/WordReveal";
import {Counter} from "../components/Counter";
import {Alaska} from "../components/Alaska";
import {Pill} from "../components/Glass";
import {T} from "../timeline";

const Node: React.FC<{cx: number; label: string; code: string; start: number; hero?: boolean}> = ({cx, label, code, start, hero}) => {
  const f = useAbs();
  const {fps} = useVideoConfig();
  const e = enter(f, start, fps, {dist: 60, scale: 0.7});
  const c = hero ? colors.hero : colors.dim;
  return (
    <div style={{position: "absolute", left: cx - 150, top: 440 + breathe(f, fps, 5, cx), width: 300, ...e.style}}>
      <div
        style={{
          width: 250,
          height: 250,
          margin: "0 auto",
          borderRadius: "50%",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          fontSize: 92,
          fontWeight: 700,
          lineHeight: 1,
          color: c,
          background: `radial-gradient(circle at 35% 30%, ${alpha(colors.surfaceHi, 0.95)}, ${alpha(colors.surface, 0.9)})`,
          border: `5px solid ${alpha(c, 0.8)}`,
          boxShadow: hero ? shadow.glowHero : shadow.card,
        }}
      >
        {code}
      </div>
      <div style={{textAlign: "center", fontSize: 58, fontWeight: 700, color: colors.text, lineHeight: 1.5, marginTop: 14}}>{label}</div>
    </div>
  );
};

const RUSSIA_X = 390;
const US_X = 1530;

const Transaction: React.FC = () => {
  const f = useAbs();
  const {fps} = useVideoConfig();
  const t0 = T.deal.price;
  const mv = interpolate(f, [t0, t0 + 34], [0, 1], {easing: ease.inOut, ...clamp});
  const tokenX = 700 + (1220 - 700) * mv;
  const chipX = 1210 + (710 - 1210) * mv;
  const tok = enter(f, T.deal.alaska, fps, {dist: 50, scale: 0.7});
  const chip = enter(f, T.deal.price, fps, {dist: 40, scale: 0.85});
  const line = interpolate(f, [T.deal.russia, T.deal.russia + 24], [0, 1], {easing: ease.out, ...clamp});
  return (
    <>
      <svg style={{position: "absolute", left: 0, top: 0}} width={1920} height={1080}>
        <line
          x1={RUSSIA_X + 135}
          y1={565}
          x2={US_X - 135}
          y2={565}
          stroke={alpha(colors.text, 0.28)}
          strokeWidth={4}
          strokeDasharray="4 16"
          strokeLinecap="round"
          opacity={line}
        />
      </svg>
      <div style={{position: "absolute", left: tokenX - 130, top: 470 + breathe(f, fps, 5, 1), width: 260, ...tok.style}}>
        <div
          style={{
            borderRadius: radius.md,
            padding: "22px 14px 10px",
            background: alpha(colors.surfaceHi, 0.9),
            border: `1.5px solid ${alpha(colors.hero, 0.5)}`,
            boxShadow: shadow.card,
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
          }}
        >
          <Alaska width={200} start={T.deal.alaska + 2} draw={20} glow={false} strokeW={5} />
          <div style={{fontSize: 40, fontWeight: 700, color: colors.text, lineHeight: 1.5, marginTop: 4}}>আলাস্কা</div>
        </div>
      </div>
      <div style={{position: "absolute", left: chipX - 290, top: 760, width: 580, display: "flex", justifyContent: "center", ...chip.style}}>
        <div
          style={{
            padding: "10px 40px",
            borderRadius: 999,
            fontSize: 56,
            fontWeight: 700,
            lineHeight: 1.45,
            color: colors.bg,
            background: `linear-gradient(180deg, ${colors.accentLight}, ${colors.accent})`,
            boxShadow: shadow.glowAccent,
          }}
        >
          ৭.২ মিলিয়ন ডলার
        </div>
      </div>
    </>
  );
};

const AcreGrid: React.FC<{start: number}> = ({start}) => {
  const f = useAbs();
  const {fps} = useVideoConfig();
  const cols = 10;
  const rows = 6;
  const sweepPos = ((f - start) * 0.18) % (cols + rows + 6);
  return (
    <div style={{position: "absolute", left: 900, top: 270, width: 940, display: "grid", gridTemplateColumns: `repeat(${cols}, 82px)`, gap: 12}}>
      {new Array(cols * rows).fill(0).map((_, i) => {
        const c = i % cols;
        const r = Math.floor(i / cols);
        const e = enter(f, start + (c + r) * 2, fps, {dist: 24, scale: 0.6, cfg: {damping: 14, stiffness: 220, mass: 0.7}});
        const near = Math.max(0, 1 - Math.abs(c + r - sweepPos) / 2.2);
        const mark = c === 6 && r === 2;
        return (
          <div
            key={i}
            style={{
              width: 82,
              height: 82,
              borderRadius: 16,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              fontSize: 32,
              fontWeight: 700,
              color: colors.bg,
              background: mark ? colors.accent : alpha(colors.hero, 0.1 + near * 0.35),
              border: `2px solid ${mark ? colors.accentLight : alpha(colors.hero, 0.28 + near * 0.5)}`,
              boxShadow: mark ? shadow.glowAccent : undefined,
              ...e.style,
            }}
          >
            {mark ? "২¢" : ""}
          </div>
        );
      })}
    </div>
  );
};

export const Deal: React.FC = () => {
  const f = useAbs();
  const {fps} = useVideoConfig();
  const bAt = T.deal.roughly;
  const aOut = exitP(f, bAt - 8, 12);
  const bIn = enter(f, bAt + 2, fps, {dist: 50, scale: 0.9, blur: 8});
  const sweep = interpolate(f, [T.deal.year + 10, T.deal.year + 30], [0, 1], {easing: ease.out, ...clamp});
  const year = prog(f, T.deal.year, fps);

  return (
    <div style={{position: "absolute", inset: 0}}>
      {f < bAt + 12 ? (
        <div style={{position: "absolute", inset: 0, ...exitStyle(aOut)}}>
          <div style={{position: "absolute", top: 70, left: 0, right: 0, display: "flex", flexDirection: "column", alignItems: "center"}}>
            <div style={{fontSize: 190, fontWeight: 700, lineHeight: 1.3, color: colors.hero, opacity: Math.min(1, year * 1.6), transform: `scale(${0.8 + 0.2 * year}) translateY(${(1 - year) * 40}px)`}}>
              ১৮৬৭
            </div>
            <div style={{width: 520 * sweep, height: 8, borderRadius: 8, background: colors.accent, marginTop: -6, boxShadow: shadow.glowAccent}} />
          </div>
          <Node cx={US_X} label="যুক্তরাষ্ট্র" code="US" start={T.deal.us} hero />
          <Node cx={RUSSIA_X} label="রাশিয়া" code="RU" start={T.deal.russia} />
          <Transaction />
        </div>
      ) : null}

      <div style={{position: "absolute", left: 130, top: 330, width: 720, ...bIn.style}}>
        <div style={{display: "flex", columnGap: 20, alignItems: "baseline"}}>
          <span style={{fontSize: 64, fontWeight: 600, color: colors.dim, lineHeight: 1.4}}>প্রায়</span>
        </div>
        <div style={{display: "flex", alignItems: "baseline", columnGap: 24}}>
          <Counter to={2} start={T.deal.cents - 2} dur={22} size={210} />
          <span style={{fontSize: 110, fontWeight: 700, color: colors.accent, lineHeight: 1.3}}>সেন্ট</span>
        </div>
        <div style={{marginTop: 10}}>
          <Pill text="প্রতি একর" size={60} color={colors.hero} />
        </div>
      </div>
      <AcreGrid start={bAt + 4} />
    </div>
  );
};
