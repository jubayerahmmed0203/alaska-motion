import React from "react";
import {interpolate, useVideoConfig} from "remotion";
import {alpha, colors, ease, radius, shadow} from "../theme";
import {breathe, clamp, enter, useAbs} from "../motion";
import {WordReveal} from "../components/WordReveal";
import {Alaska} from "../components/Alaska";
import {T} from "../timeline";

const Bar: React.FC<{w: number; h?: number; c?: string}> = ({w, h = 14, c}) => (
  <div style={{width: w, height: h, borderRadius: h, background: c ?? alpha(colors.bg, 0.2)}} />
);

const Bubble: React.FC<{start: number; icon: string; w: number}> = ({start, icon, w}) => {
  const f = useAbs();
  const {fps} = useVideoConfig();
  const e = enter(f, start, fps, {dist: 40, x: 60, scale: 0.85});
  return (
    <div
      style={{
        position: "relative",
        boxSizing: "border-box",
        width: 700,
        height: 124,
        borderRadius: 62,
        display: "flex",
        alignItems: "center",
        columnGap: 28,
        padding: "0 36px",
        background: `linear-gradient(145deg, ${alpha(colors.surfaceHi, 0.9)}, ${alpha(colors.surface, 0.85)})`,
        border: `1.5px solid ${alpha(colors.text, 0.14)}`,
        boxShadow: shadow.card,
        ...e.style,
      }}
    >
      <div
        style={{
          width: 72,
          height: 72,
          borderRadius: "50%",
          flexShrink: 0,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          fontSize: 48,
          fontWeight: 700,
          lineHeight: 1,
          color: colors.bg,
          background: colors.hero,
        }}
      >
        {icon}
      </div>
      <div style={{display: "flex", flexDirection: "column", rowGap: 14}}>
        <Bar w={w} c={alpha(colors.text, 0.35)} />
        <Bar w={w * 0.62} c={alpha(colors.text, 0.2)} />
      </div>
    </div>
  );
};

export const Folly: React.FC = () => {
  const f = useAbs();
  const {fps} = useVideoConfig();
  const paper = enter(f, T.folly.critics - 4, fps, {dist: 80, x: -60, scale: 0.9, cfg: {damping: 18, stiffness: 140, mass: 1}});
  const focus = interpolate(f, [T.folly.name, T.folly.name + 18], [0, 1], {easing: ease.out, ...clamp});
  const head = enter(f, T.folly.calling, fps, {dist: 40, scale: 0.9, blur: 8});
  const sweep = interpolate(f, [T.folly.name + 6, T.folly.name + 22], [0, 1], {easing: ease.out, ...clamp});

  return (
    <div style={{position: "absolute", inset: 0}}>
      {/* সংবাদপত্রের কার্ড */}
      <div
        style={{
          position: "absolute",
          left: 150,
          top: 190 + breathe(f, fps, 5, 0),
          width: 820,
          height: 700,
          transform: `rotate(${-3 + focus * 3}deg) scale(${1 + focus * 0.04})`,
        }}
      >
        <div
          style={{
            boxSizing: "border-box",
            width: "100%",
            height: "100%",
            borderRadius: radius.md,
            padding: "46px 52px",
            background: alpha(colors.text, 0.97),
            boxShadow: `${shadow.card}, 0 0 0 ${focus * 6}px ${alpha(colors.accent, focus * 0.9)}`,
            ...paper.style,
          }}
        >
          <div style={{display: "flex", justifyContent: "space-between", alignItems: "center"}}>
            <Bar w={260} h={18} c={alpha(colors.bg, 0.45)} />
            <Bar w={120} h={18} c={alpha(colors.bg, 0.2)} />
          </div>
          <div style={{height: 8, background: alpha(colors.bg, 0.8), margin: "22px 0 24px", borderRadius: 4}} />
          <div style={{position: "relative", display: "inline-block", ...head.style}}>
            <div
              style={{
                position: "absolute",
                left: -10,
                right: -10,
                top: "20%",
                height: "62%",
                background: alpha(colors.accent, 0.55),
                borderRadius: 10,
                transformOrigin: "left center",
                transform: `scaleX(${sweep})`,
              }}
            />
            <div style={{position: "relative", fontSize: 92, fontWeight: 700, color: colors.bg, lineHeight: 1.3, letterSpacing: 0, whiteSpace: "nowrap"}}>
              Seward's Folly
            </div>
          </div>
          <div style={{display: "flex", columnGap: 30, marginTop: 34}}>
            <div
              style={{
                width: 270,
                height: 250,
                borderRadius: 18,
                background: alpha(colors.bg, 0.1),
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              <Alaska width={220} start={T.folly.critics + 6} draw={26} glow={false} stroke={colors.bg} fill={alpha(colors.bg, 0.22)} strokeW={5} />
            </div>
            <div style={{display: "flex", flexDirection: "column", rowGap: 22, paddingTop: 8}}>
              {[330, 360, 300, 350, 240].map((w, i) => (
                <Bar key={i} w={w} h={16} />
              ))}
            </div>
          </div>
          <div style={{display: "flex", flexDirection: "column", rowGap: 20, marginTop: 36}}>
            <Bar w={680} h={16} />
            <Bar w={560} h={16} />
          </div>
        </div>
      </div>

      {/* ডানে: সমালোচকদের ব্যঙ্গ */}
      <div style={{position: "absolute", left: 1040, top: 190, width: 760}}>
        <WordReveal
          text="সমালোচকরা ঠাট্টা করলেন"
          start={T.folly.critics}
          size={86}
          align="left"
          maxWidth={760}
          wordColors={[undefined, colors.hero, undefined]}
          sweep={[1]}
          sweepColor={colors.hero}
        />
      </div>
      <div style={{position: "absolute", left: 1040, top: 470, display: "flex", flexDirection: "column", rowGap: 28}}>
        <Bubble start={T.folly.critics + 14} icon="?" w={360} />
        <Bubble start={T.folly.critics + 28} icon="!" w={300} />
        <Bubble start={T.folly.calling} icon="…" w={330} />
      </div>
    </div>
  );
};
