import React from "react";
import {interpolate, useVideoConfig} from "remotion";
import {alpha, colors, ease, shadow} from "../theme";
import {breathe, clamp, enter, exitP, exitStyle, useAbs} from "../motion";
import {Glass, Pill} from "../components/Glass";
import {Expand, Layers, Mountain} from "../components/Icons";
import {Alaska, ALASKA_VIEW} from "../components/Alaska";
import {T} from "../timeline";

const MAP_W = 660;
const MAP_H = (MAP_W * ALASKA_VIEW.h) / ALASKA_VIEW.w;
const MAP_L = (1920 - MAP_W) / 2;
const MAP_T = 270;

const Chip: React.FC<{left: number; top: number; start: number; label: string; icon: React.ReactNode; fromX: number}> = ({left, top, start, label, icon, fromX}) => {
  const f = useAbs();
  const {fps} = useVideoConfig();
  const e = enter(f, start, fps, {dist: 30, x: fromX, scale: 0.85});
  return (
    <div style={{position: "absolute", left, top: top + breathe(f, fps, 5, left), ...e.style}}>
      <Glass w={470} h={138} r={69} border={alpha(colors.hero, 0.35)}>
        <div style={{position: "absolute", inset: 0, display: "flex", alignItems: "center", columnGap: 22, padding: "0 34px"}}>
          <div style={{flexShrink: 0, width: 76, height: 76, display: "flex", alignItems: "center", justifyContent: "center"}}>{icon}</div>
          <div style={{fontSize: 46, fontWeight: 700, color: colors.text, lineHeight: 1.35, letterSpacing: 0}}>{label}</div>
        </div>
      </Glass>
    </div>
  );
};

const Spoke: React.FC<{x1: number; y1: number; x2: number; y2: number; start: number}> = ({x1, y1, x2, y2, start}) => {
  const f = useAbs();
  const d = interpolate(f, [start + 4, start + 26], [0, 1], {easing: ease.out, ...clamp});
  return (
    <>
      <line x1={x1} y1={y1} x2={x2} y2={y2} stroke={alpha(colors.hero, 0.6)} strokeWidth={4} strokeDasharray="6 14" strokeLinecap="round" opacity={d} />
      <circle cx={x2} cy={y2} r={11 * d} fill={colors.hero} />
    </>
  );
};

export const Giant: React.FC = () => {
  const f = useAbs();
  const {fps} = useVideoConfig();
  const out = exitP(f, T.giant.today - 4, 10);
  const val = enter(f, T.giant.value, fps, {dist: 30, scale: 0.8});
  const label = enter(f, T.giant.today, fps, {dist: 20, scale: 0.9});
  return (
    <div style={{position: "absolute", inset: 0}}>
      <div style={{position: "absolute", left: MAP_L, top: MAP_T + breathe(f, fps, 6, 0)}}>
        <Alaska width={MAP_W} start={4} draw={46} />
      </div>
      <div style={{position: "absolute", left: 0, right: 0, top: MAP_T + MAP_H + 10, display: "flex", justifyContent: "center", ...label.style}}>
        <div style={{fontSize: 84, fontWeight: 700, color: colors.hero, lineHeight: 1.4}}>আলাস্কা</div>
      </div>

      <svg style={{position: "absolute", left: 0, top: 0}} width={1920} height={1080}>
        <Spoke x1={600} y1={370} x2={MAP_L + 250} y2={MAP_T + 190} start={T.giant.largest} />
        <Spoke x1={1320} y1={340} x2={MAP_L + 420} y2={MAP_T + 170} start={T.giant.natural} />
        <Spoke x1={600} y1={740} x2={MAP_L + 350} y2={MAP_T + 250} start={T.giant.wild} />
      </svg>

      {/* "more value." */}
      <div style={{position: "absolute", left: 0, right: 0, top: 110, display: "flex", justifyContent: "center", ...val.style, ...exitStyle(out, -24)}}>
        <Pill text="আরও মূল্য" size={60} color={colors.accent} />
      </div>

      <Chip left={130} top={300} start={T.giant.largest} label="আয়তনে সবচেয়ে বড়" icon={<Expand size={72} />} fromX={-90} />
      <Chip left={1330} top={270} start={T.giant.natural} label="প্রাকৃতিক সম্পদ" icon={<Layers size={72} />} fromX={90} />
      <Chip left={130} top={700} start={T.giant.wild} label="অপূর্ব বন্যপ্রকৃতি" icon={<Mountain size={76} />} fromX={-90} />
    </div>
  );
};
