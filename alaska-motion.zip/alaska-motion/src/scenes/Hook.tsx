import React from "react";
import {useVideoConfig} from "remotion";
import {alpha, colors, ease, shadow} from "../theme";
import {breathe, enter, exitP, exitStyle, useAbs} from "../motion";
import {WordReveal} from "../components/WordReveal";
import {Counter} from "../components/Counter";
import {Alaska, ALASKA_VIEW} from "../components/Alaska";
import {T} from "../timeline";

const Coin: React.FC<{start: number}> = ({start}) => {
  const f = useAbs();
  const {fps} = useVideoConfig();
  const e = enter(f, start, fps, {dist: 90, scale: 0.6});
  const cycle = 56;
  const ph = (((f - start) % cycle) + cycle) % cycle / cycle;
  const ang = 360 * ease.inOut(ph);
  const lift = -70 * 4 * ph * (1 - ph);
  const face: React.CSSProperties = {
    position: "absolute",
    inset: 0,
    borderRadius: "50%",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    backfaceVisibility: "hidden",
    fontWeight: 700,
    fontSize: 170,
    lineHeight: 1,
  };
  return (
    <div style={{width: 260, height: 340, position: "relative", ...e.style}}>
      <div
        style={{
          position: "absolute",
          left: 30,
          bottom: 0,
          width: 200,
          height: 28,
          borderRadius: "50%",
          background: alpha(colors.bgDeep, 0.7),
          filter: "blur(10px)",
          transform: `scale(${1 + lift / 400})`,
        }}
      />
      <div style={{position: "absolute", left: 0, top: 40, width: 260, height: 260, perspective: 900, transform: `translateY(${lift}px)`}}>
        <div style={{position: "relative", width: "100%", height: "100%", transformStyle: "preserve-3d", transform: `rotateX(${ang}deg)`}}>
          <div
            style={{
              ...face,
              color: colors.bg,
              background: `radial-gradient(circle at 35% 30%, ${colors.accentLight}, ${colors.accent} 45%, ${colors.accentDark})`,
              boxShadow: `${shadow.glowAccent}, inset 0 0 0 10px ${alpha(colors.accentDark, 0.55)}`,
            }}
          >
            $
          </div>
          <div
            style={{
              ...face,
              transform: "rotateX(180deg)",
              color: colors.bg,
              background: `radial-gradient(circle at 35% 30%, ${colors.text}, ${colors.hero} 50%, ${colors.surfaceHi})`,
              boxShadow: `${shadow.glowHero}, inset 0 0 0 10px ${alpha(colors.surfaceHi, 0.55)}`,
            }}
          >
            ?
          </div>
        </div>
      </div>
    </div>
  );
};

export const Hook: React.FC = () => {
  const f = useAbs();
  const {fps} = useVideoConfig();
  const bAt = T.hook.q;
  const aOut = exitP(f, bAt - 8, 12);
  const mapW = 640;
  const mapH = (mapW * ALASKA_VIEW.h) / ALASKA_VIEW.w;
  const price = enter(f, T.hook.price, fps, {dist: 50, scale: 0.9, blur: 8});

  return (
    <div style={{position: "absolute", inset: 0}}>
      {/* A: একটি পুরো রাজ্য, মাত্র ৭.২ মিলিয়ন ডলারে */}
      {f < bAt + 14 ? (
        <div style={{position: "absolute", inset: 0, ...exitStyle(aOut)}}>
          <div style={{position: "absolute", top: 70, left: 0, right: 0, display: "flex", justifyContent: "center"}}>
            <WordReveal text="একটি পুরো রাজ্য!" start={4} size={128} stagger={5} wordColors={[undefined, undefined, undefined]} />
          </div>
          <div
            style={{
              position: "absolute",
              top: 255 + breathe(f, fps, 6, 0),
              left: (1920 - mapW) / 2,
              width: mapW,
              height: mapH,
            }}
          >
            <Alaska width={mapW} start={10} draw={44} />
          </div>
          <div
            style={{
              position: "absolute",
              top: 850,
              left: 0,
              right: 0,
              display: "flex",
              justifyContent: "center",
              alignItems: "baseline",
              columnGap: 28,
              ...price.style,
            }}
          >
            <span style={{fontSize: 64, fontWeight: 600, color: colors.dim, lineHeight: 1.4}}>মাত্র</span>
            <Counter to={7.2} decimals={1} start={T.hook.price} dur={34} size={136} />
            <span style={{fontSize: 84, fontWeight: 700, color: colors.text, lineHeight: 1.4}}>মিলিয়ন ডলার</span>
          </div>
        </div>
      ) : null}

      {/* B: বুদ্ধিমানের চুক্তি নাকি বড় ভুল? */}
      <div style={{position: "absolute", top: 60, left: 0, right: 0, display: "flex", justifyContent: "center"}}>
        <Coin start={bAt} />
      </div>
      <div style={{position: "absolute", top: 450, left: 0, right: 0, display: "flex", justifyContent: "center"}}>
        <WordReveal
          text="বুদ্ধিমানের চুক্তি"
          start={0}
          size={124}
          wordStarts={[T.hook.genius, T.hook.genius + 4]}
          wordColors={[colors.accent, colors.accent]}
          sweep={[1]}
        />
      </div>
      <div style={{position: "absolute", top: 640, left: 0, right: 0, display: "flex", justifyContent: "center"}}>
        <WordReveal
          text="নাকি বড় ভুল?"
          start={0}
          size={124}
          wordStarts={[T.hook.nakhi, T.hook.mistake, T.hook.mistake + 4]}
          wordColors={[colors.dim, colors.hero, colors.hero]}
          sweep={[2]}
          sweepColor={colors.hero}
        />
      </div>
    </div>
  );
};
