import React from "react";
import {interpolate, useVideoConfig} from "remotion";
import {alpha, colors, ease, radius, shadow} from "../theme";
import {breathe, clamp, enter, exitP, exitStyle, prog, useAbs} from "../motion";
import {WordReveal} from "../components/WordReveal";
import {Counter} from "../components/Counter";
import {StarPoly} from "../components/Icons";
import {T} from "../timeline";

const Deed: React.FC = () => {
  const f = useAbs();
  const {fps} = useVideoConfig();
  const e = enter(f, T.owner.imagine, fps, {dist: 90, x: -40, scale: 0.88, cfg: {damping: 18, stiffness: 140, mass: 1}});
  const seal = prog(f, T.owner.land, fps, {damping: 9, stiffness: 240, mass: 0.7});
  const sig = interpolate(f, [T.owner.land - 10, T.owner.land + 26], [0, 1], {easing: ease.inOut, ...clamp});
  const Bar = ({w, h = 16, c}: {w: number; h?: number; c?: string}) => <div style={{width: w, height: h, borderRadius: h, background: c ?? alpha(colors.bg, 0.2)}} />;
  return (
    <div style={{position: "absolute", left: 170, top: 130 + breathe(f, fps, 5, 0), width: 700, height: 820, transform: "rotate(-3deg)"}}>
      <div style={{boxSizing: "border-box", width: "100%", height: "100%", borderRadius: radius.md, padding: "54px 56px", background: alpha(colors.text, 0.97), boxShadow: shadow.card, ...e.style}}>
        <div style={{fontSize: 62, fontWeight: 700, color: colors.bg, lineHeight: 1.4, letterSpacing: 0}}>মালিকানা দলিল</div>
        <div style={{height: 7, borderRadius: 4, background: alpha(colors.bg, 0.8), margin: "10px 0 34px"}} />
        <div style={{display: "flex", flexDirection: "column", rowGap: 26}}>
          {[560, 590, 520, 580, 440, 560, 360].map((w, i) => (
            <Bar key={i} w={w} />
          ))}
        </div>
        <svg width={420} height={120} viewBox="0 0 420 120" style={{marginTop: 40}}>
          <path d="M10 80 C 40 10, 70 110, 100 50 S 150 20, 170 70 S 230 100, 260 40 S 330 60, 400 50" pathLength={1} fill="none" stroke={colors.bg} strokeWidth={6} strokeLinecap="round" strokeDasharray={1} strokeDashoffset={1 - sig} />
        </svg>
        <div
          style={{
            position: "absolute",
            right: 50,
            bottom: 46,
            width: 190,
            height: 190,
            borderRadius: "50%",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            background: `radial-gradient(circle at 35% 30%, ${colors.accentLight}, ${colors.accent} 50%, ${colors.accentDark})`,
            boxShadow: `0 0 0 8px ${alpha(colors.accentDark, 0.35)}, ${shadow.glowAccent}`,
            opacity: Math.min(1, seal * 1.5),
            transform: `scale(${1.6 - 0.6 * seal}) rotate(${(1 - seal) * -25}deg)`,
          }}
        >
          <StarPoly size={96} color={colors.bg} />
        </div>
      </div>
    </div>
  );
};

export const Owner: React.FC = () => {
  const f = useAbs();
  const {fps} = useVideoConfig();
  const bAt = T.owner.ask;
  const aOut = exitP(f, bAt - 8, 12);
  const q = enter(f, bAt, fps, {dist: 60, scale: 0.7, blur: 12});
  const bigQ = interpolate(f, [bAt, bAt + 30], [0, 1], {easing: ease.out, ...clamp});
  const price = enter(f, T.owner.price - 6, fps, {dist: 40, scale: 0.9, blur: 8});

  return (
    <div style={{position: "absolute", inset: 0}}>
      {f < bAt + 14 ? (
        <div style={{position: "absolute", inset: 0, ...exitStyle(aOut)}}>
          <Deed />
          <div style={{position: "absolute", left: 960, top: 240, width: 860}}>
            <WordReveal text="কল্পনা করুন" start={T.owner.imagine} size={70} weight={600} color={colors.dim} align="left" />
            <WordReveal text="এত বিশাল জমির মালিক" start={T.owner.land} size={92} align="left" maxWidth={860} sweep={[2]} />
            <div style={{marginTop: 26, display: "flex", alignItems: "baseline", columnGap: 20, ...price.style}}>
              <span style={{fontSize: 60, fontWeight: 600, color: colors.dim, lineHeight: 1.4}}>মাত্র</span>
              <Counter to={7.2} decimals={1} start={T.owner.price - 4} dur={30} size={150} />
            </div>
            <div style={{fontSize: 96, fontWeight: 700, color: colors.text, lineHeight: 1.35, ...price.style}}>মিলিয়ন ডলারে</div>
          </div>
        </div>
      ) : null}

      <div style={{position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center", opacity: 0.1 * bigQ, fontSize: 1100, fontWeight: 700, lineHeight: 1, color: colors.hero, transform: `scale(${0.8 + 0.2 * bigQ})`}}>
        ?
      </div>
      <div style={{position: "absolute", left: 0, right: 0, top: 380, display: "flex", justifyContent: "center", ...q.style}}>
        <WordReveal text="আপনার কী মনে হয়?" start={bAt + 2} size={150} stagger={6} wordColors={[colors.text, colors.text, colors.hero, colors.hero]} />
      </div>
    </div>
  );
};
