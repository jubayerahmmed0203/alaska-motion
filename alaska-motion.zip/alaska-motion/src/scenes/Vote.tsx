import React from "react";
import {interpolate, useVideoConfig} from "remotion";
import {alpha, colors, ease, shadow} from "../theme";
import {breathe, clamp, enter, useAbs} from "../motion";
import {WordReveal} from "../components/WordReveal";
import {Glass} from "../components/Glass";
import {Check, Cross} from "../components/Icons";
import {T} from "../timeline";

const Choice: React.FC<{left: number; start: number; label: string; hero?: boolean; seed: number}> = ({left, start, label, hero, seed}) => {
  const f = useAbs();
  const {fps} = useVideoConfig();
  const e = enter(f, start, fps, {dist: 70, scale: 0.85});
  const c = hero ? colors.hero : colors.accent;
  return (
    <div style={{position: "absolute", left, top: 530 + breathe(f, fps, 5, seed), width: 700, height: 250, ...e.style}}>
      <Glass w={700} h={250} border={alpha(c, 0.55)} style={{boxShadow: `${shadow.card}, 0 0 50px ${alpha(c, 0.22)}`}}>
        <div style={{position: "absolute", inset: 0, display: "flex", alignItems: "center", columnGap: 32, padding: "0 44px"}}>
          <div style={{flexShrink: 0, width: 112, height: 112, borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", background: c}}>
            {hero ? <Cross size={64} /> : <Check size={68} />}
          </div>
          <div style={{fontSize: 70, fontWeight: 700, color: colors.text, lineHeight: 1.35, letterSpacing: 0}}>{label}</div>
        </div>
      </Glass>
    </div>
  );
};

export const Vote: React.FC = () => {
  const f = useAbs();
  const {fps} = useVideoConfig();
  const cta = enter(f, T.vote.ever + 8, fps, {dist: 24, scale: 0.95});
  const rule = interpolate(f, [T.vote.q + 6, T.vote.q + 30], [0, 1], {easing: ease.out, ...clamp});
  return (
    <div style={{position: "absolute", inset: 0}}>
      <div style={{position: "absolute", top: 100, left: 0, right: 0, height: 320, display: "flex", justifyContent: "center", alignItems: "center"}}>
        <WordReveal
          text="আমেরিকার সবচেয়ে স্মার্ট রিয়েল এস্টেট ডিল?"
          start={T.vote.q}
          size={92}
          stagger={3}
          maxWidth={1500}
          wordColors={[undefined, undefined, colors.accent, undefined, undefined, undefined]}
          sweep={[2]}
        />
      </div>
      <div style={{position: "absolute", top: 446, left: 960 - 260 * rule, width: 520 * rule, height: 6, borderRadius: 6, background: alpha(colors.text, 0.25)}} />
      <Choice left={190} start={T.vote.smartest} label="বুদ্ধিমানের চুক্তি" seed={0} />
      <Choice left={1030} start={T.vote.smartest + 8} label="বড় ভুল" hero seed={2} />
      <div style={{position: "absolute", left: 0, right: 0, top: 860, display: "flex", justifyContent: "center", ...cta.style}}>
        <div style={{fontSize: 52, fontWeight: 600, color: colors.dim, lineHeight: 1.4}}>আপনার মত কমেন্টে জানান</div>
      </div>
    </div>
  );
};
