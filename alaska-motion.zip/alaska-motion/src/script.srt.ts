// ইউজারের দেওয়া SRT। সব টাইমিং এখান থেকেই হিসাব হয় (timeline.ts)।
export const SRT = `1
00:00:00,200 --> 00:00:05,940
America bought an entire state for just
7.2 million dollars, but was it a genius

2
00:00:05,940 --> 00:00:07,400
deal or a huge mistake?

3
00:00:08,119 --> 00:00:14,060
Back in 1867, the United States bought
Alaska from Russia for just 7.2 million

4
00:00:14,060 --> 00:00:16,700
dollars. That's roughly two cents per
acre.

5
00:00:17,340 --> 00:00:21,180
At the time, critics mocked the purchase,
calling it Seward's Folly.

6
00:00:21,780 --> 00:00:26,580
But then came the gold rush, and later,
Alaska's massive oil reserves added even

7
00:00:26,580 --> 00:00:32,060
more value. Today, Alaska is America's
largest state by area, packed with natural

8
00:00:32,060 --> 00:00:34,360
resources and breathtaking wilderness.

9
00:00:35,040 --> 00:00:41,320
Imagine owning all that land for just 7.2
million dollars. So, what do you think?

10
00:00:41,320 --> 00:00:43,560
Was this America's smartest real estate
deal ever?
`;
