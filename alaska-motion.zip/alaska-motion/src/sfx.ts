import {T, scenes} from "./timeline";

export type SfxName = "whoosh" | "swipe" | "pop" | "click" | "chime" | "thud";
export type SfxEvent = {f: number; name: SfxName; vol: number};

// একই ধরনের ইভেন্টে একই সাউন্ড; পরপর ব্যবহারে সামান্য ভলিউম ভ্যারিয়েশন
const ev = (f: number, name: SfxName, vol: number): SfxEvent => ({f: Math.max(0, f), name, vol});

export const sfxEvents: SfxEvent[] = [
  // হুক
  ev(2, "thud", 0.3),
  ev(6, "whoosh", 0.22),
  ev(T.hook.price + 34, "chime", 0.26),
  ev(T.hook.q, "pop", 0.3),
  ev(T.hook.genius, "click", 0.34),
  ev(T.hook.mistake, "click", 0.34),
  // ১৮৬৭: লেনদেন
  ev(T.deal.year, "whoosh", 0.22),
  ev(T.deal.us, "pop", 0.3),
  ev(T.deal.russia, "pop", 0.27),
  ev(T.deal.price, "whoosh", 0.2),
  ev(T.deal.roughly + 4, "pop", 0.3),
  ev(T.deal.cents + 6, "click", 0.34),
  // সিওয়ার্ডের বোকামি
  ev(T.folly.critics, "pop", 0.28),
  ev(T.folly.critics + 14, "pop", 0.25),
  ev(T.folly.name, "click", 0.34),
  // গোল্ড রাশ ও তেল
  ev(T.boom.gold, "pop", 0.3),
  ev(T.boom.oil, "pop", 0.27),
  ev(T.boom.value, "chime", 0.24),
  // সবচেয়ে বড় রাজ্য
  ev(T.giant.value, "pop", 0.26),
  ev(T.giant.largest, "pop", 0.3),
  ev(T.giant.natural, "pop", 0.27),
  ev(T.giant.wild, "pop", 0.29),
  // মালিকানা
  ev(T.owner.land, "chime", 0.26),
  ev(T.owner.ask, "whoosh", 0.22),
  // ভোট
  ev(T.vote.smartest, "pop", 0.3),
  ev(T.vote.ever, "pop", 0.27),
  // সিন ট্রানজিশন
  ...scenes.slice(1).map((s, i) => ev(s.from, "swipe", 0.2 + (i % 2) * 0.03)),
].sort((a, b) => a.f - b.f);
