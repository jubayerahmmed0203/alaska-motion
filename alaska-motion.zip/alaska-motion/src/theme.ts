import {Easing} from "remotion";
import {loadFont} from "@remotion/google-fonts/HindSiliguri";

export const FPS = 30;
export const WIDTH = 1920;
export const HEIGHT = 1080;

// স্কিম: Arctic Night (ইউজারের পছন্দ ১)
export const colors = {
  bg: "#0A1628",
  hero: "#4FC3F7",
  accent: "#FFD166",
  text: "#F2F7FB",
  // স্কিম থেকে তৈরি সহায়ক রং
  bgDeep: "#050C18",
  surface: "#0F2240",
  surfaceHi: "#16335C",
  dim: "#9DB2C9",
  accentDark: "#C9962B",
  accentLight: "#FFE9A8",
} as const;

export const alpha = (hex: string, a: number): string => {
  const n = parseInt(hex.slice(1), 16);
  return `rgba(${(n >> 16) & 255}, ${(n >> 8) & 255}, ${n & 255}, ${a})`;
};

// Hind Siliguri: যুক্তাক্ষর ঠিক আসে, সর্বোচ্চ ওজন 700
const loaded = loadFont("normal", {
  weights: ["400", "500", "600", "700"],
  subsets: ["bengali", "latin"],
});
export const fontFamily = `${loaded.fontFamily}, "Noto Sans Bengali", "Kalpurush", sans-serif`;

export const ease = {
  out: Easing.bezier(0.16, 1, 0.3, 1),
  inOut: Easing.bezier(0.65, 0, 0.35, 1),
  in: Easing.bezier(0.7, 0, 0.84, 0),
  back: Easing.bezier(0.34, 1.56, 0.64, 1),
};

export const springs = {
  pop: {damping: 13, stiffness: 190, mass: 0.8},
  soft: {damping: 22, stiffness: 120, mass: 1},
  snap: {damping: 17, stiffness: 260, mass: 0.7},
  heavy: {damping: 20, stiffness: 90, mass: 1.1},
};

export const radius = {sm: 16, md: 28, lg: 44};

export const shadow = {
  card: `0 30px 80px ${alpha(colors.bgDeep, 0.55)}, 0 0 0 1.5px ${alpha(colors.text, 0.1)} inset`,
  glowHero: `0 0 60px ${alpha(colors.hero, 0.35)}`,
  glowAccent: `0 0 60px ${alpha(colors.accent, 0.4)}`,
};

export const type = {
  hero: 190,
  h1: 120,
  h2: 92,
  h3: 64,
  body: 44,
  small: 34,
};

export const EXIT_FRAMES = 12;
export const LEAD_FRAMES = 5; // ভিজ্যুয়াল কথার ৪-৬ ফ্রেম আগে
export const OVERLAP_FRAMES = 10;
export const TAIL_SECONDS = 0.5;
