import {SRT} from "./script.srt";
import {FPS, LEAD_FRAMES, OVERLAP_FRAMES, TAIL_SECONDS} from "./theme";

export type Cue = {n: number; start: number; end: number; text: string};

const toSec = (h: string, m: string, s: string, ms: string) =>
  Number(h) * 3600 + Number(m) * 60 + Number(s) + Number(ms) / 1000;

export function parseSrt(raw: string): Cue[] {
  return raw
    .replace(/\r/g, "")
    .trim()
    .split(/\n\s*\n/)
    .map((block) => {
      const lines = block.split("\n");
      const m = lines[1].match(
        /(\d+):(\d+):(\d+)[,.](\d+)\s*-->\s*(\d+):(\d+):(\d+)[,.](\d+)/,
      );
      if (!m) throw new Error(`SRT parse error: ${block}`);
      return {
        n: Number(lines[0]),
        start: toSec(m[1], m[2], m[3], m[4]),
        end: toSec(m[5], m[6], m[7], m[8]),
        text: lines.slice(2).join(" ").replace(/\s+/g, " ").trim(),
      };
    });
}

export const cues = parseSrt(SRT);
const cue = (n: number) => cues[n - 1];

/** cue-র শুরুর ফ্রেম (absolute) */
export const cueStart = (n: number) => Math.round(cue(n).start * FPS);
export const cueEnd = (n: number) => Math.round(cue(n).end * FPS);

/**
 * cue-র লেখায় কোনো phrase কোথায় আছে তার অনুপাত ধরে কথার আনুমানিক সময় (SRT থেকেই),
 * তারপর LEAD_FRAMES আগে। cueNo না দিলে প্রথম মিল।
 */
export function at(phrase: string, cueNo?: number): number {
  const p = phrase.toLowerCase();
  const list = cueNo ? [cue(cueNo)] : cues;
  for (const c of list) {
    const t = c.text.toLowerCase();
    const i = t.indexOf(p);
    if (i >= 0) {
      const sec = c.start + (i / t.length) * (c.end - c.start);
      return Math.max(0, Math.round(sec * FPS) - LEAD_FRAMES);
    }
  }
  throw new Error(`SRT-তে phrase পাওয়া যায়নি: "${phrase}"`);
}

export const TOTAL_FRAMES = Math.round((cue(cues.length).end + TAIL_SECONDS) * FPS);

// সিনের সীমা সবসময় cue-র সীমায়
const sceneCues: Array<{id: string; a: number; b: number}> = [
  {id: "hook", a: 1, b: 2},
  {id: "deal", a: 3, b: 4},
  {id: "folly", a: 5, b: 5},
  {id: "boom", a: 6, b: 6},
  {id: "giant", a: 7, b: 8},
  {id: "owner", a: 9, b: 9},
  {id: "vote", a: 10, b: 10},
];

export const scenes = sceneCues.map((s, i, arr) => {
  const from = i === 0 ? 0 : Math.max(0, cueStart(s.a) - LEAD_FRAMES);
  const next = arr[i + 1];
  const to = next
    ? Math.max(0, cueStart(next.a) - LEAD_FRAMES) + OVERLAP_FRAMES
    : TOTAL_FRAMES;
  return {id: s.id, from, to, dur: to - from, voiceStart: cueStart(s.a), voiceEnd: cueEnd(s.b)};
});

export const T = {
  hook: {
    price: at("for just", 1),
    q: at("but was it", 1),
    genius: at("genius", 1),
    nakhi: at("deal or", 2),
    mistake: at("huge mistake", 2),
  },
  deal: {
    year: at("1867", 3),
    us: at("united states", 3),
    alaska: at("alaska", 3),
    russia: at("russia", 3),
    price: at("7.2 million", 3),
    roughly: at("roughly", 4),
    cents: at("two cents", 4),
    acre: at("per acre", 4),
  },
  folly: {
    critics: at("critics", 5),
    calling: at("calling it", 5),
    name: at("seward's folly", 5),
  },
  boom: {
    gold: at("gold rush", 6),
    oil: at("oil", 6),
    value: at("added even", 6),
  },
  giant: {
    value: at("more value", 7),
    today: at("today", 7),
    largest: at("largest state", 7),
    natural: at("natural", 7),
    wild: at("wilderness", 8),
  },
  owner: {
    imagine: at("imagine", 9),
    land: at("all that land", 9),
    price: at("7.2", 9),
    ask: at("so, what do you think", 9),
  },
  vote: {
    q: at("was this", 10),
    smartest: at("smartest", 10),
    deal: at("real estate", 10),
    ever: at("ever", 10),
  },
};
